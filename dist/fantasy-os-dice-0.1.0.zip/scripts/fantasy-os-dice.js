import {
  buildDiceFormula,
  DICE_LIMITS,
  DICE_SIDES,
  getFoundryMessageMode,
  normalizeVisibilityMode,
} from "./dice-formula.js";

const MODULE_ID = "fantasy-os-dice";
const ROOT_ID = "fantasy-os-dice-root";
const MAX_CUSTOM_FORMULA_LENGTH = 200;

function localize(key) {
  return game.i18n.localize(`FOSDice.${key}`);
}

function getRollClass() {
  return globalThis.foundry?.dice?.Roll ?? globalThis.Roll;
}

function getChatMessageClass() {
  return globalThis.foundry?.documents?.ChatMessage ?? globalThis.ChatMessage;
}

function getFoundryGeneration() {
  return Number(game.release?.generation ?? game.version?.split(".")[0] ?? 13);
}

class FantasyOSDiceTray {
  constructor() {
    this.root = null;
    this.launcher = null;
    this.panel = null;
    this.countInput = null;
    this.modifierInput = null;
    this.visibilitySelect = null;
    this.preview = null;
    this.customFormulaInput = null;
    this.isRolling = false;
    this.handleKeydown = this.handleKeydown.bind(this);
  }

  mount() {
    document.getElementById(ROOT_ID)?.remove();

    this.root = document.createElement("div");
    this.root.id = ROOT_ID;
    this.root.className = "fos-dice";
    this.root.innerHTML = this.renderMarkup();
    document.body.append(this.root);

    this.launcher = this.root.querySelector("[data-action='toggle']");
    this.panel = this.root.querySelector("[data-part='panel']");
    this.countInput = this.root.querySelector("[name='dice-count']");
    this.modifierInput = this.root.querySelector("[name='dice-modifier']");
    this.visibilitySelect = this.root.querySelector("[name='visibility']");
    this.preview = this.root.querySelector("[data-part='preview']");
    this.customFormulaInput = this.root.querySelector("[name='custom-formula']");

    this.bindEvents();
    this.updatePreview();
    document.addEventListener("keydown", this.handleKeydown);
  }

  renderMarkup() {
    const diceButtons = DICE_SIDES.map((sides) => `
      <button class="fos-dice__die" type="button" data-action="quick-roll" data-sides="${sides}" aria-label="${localize("RollD")}${sides}">
        <span class="fos-dice__die-shape" aria-hidden="true">${sides}</span>
        <span>d${sides}</span>
      </button>
    `).join("");

    return `
      <button
        class="fos-dice__launcher"
        type="button"
        data-action="toggle"
        aria-controls="fos-dice-panel"
        aria-expanded="false"
        title="${localize("OpenTray")}">
        <i class="fa-solid fa-dice-d20" aria-hidden="true"></i>
        <span>${localize("Launcher")}</span>
      </button>

      <section
        class="fos-dice__panel"
        id="fos-dice-panel"
        data-part="panel"
        aria-labelledby="fos-dice-title"
        hidden>
        <header class="fos-dice__header">
          <div>
            <p class="fos-dice__eyebrow">Fantasy-OS</p>
            <h2 id="fos-dice-title">${localize("Title")}</h2>
          </div>
          <button class="fos-dice__icon-button" type="button" data-action="close" aria-label="${localize("Close")}" title="${localize("Close")}">
            <i class="fa-solid fa-xmark" aria-hidden="true"></i>
          </button>
        </header>

        <div class="fos-dice__body">
          <div class="fos-dice__controls">
            <label>
              <span>${localize("Count")}</span>
              <input name="dice-count" type="number" min="${DICE_LIMITS.count.min}" max="${DICE_LIMITS.count.max}" value="1" inputmode="numeric">
            </label>
            <label>
              <span>${localize("Modifier")}</span>
              <input name="dice-modifier" type="number" min="${DICE_LIMITS.modifier.min}" max="${DICE_LIMITS.modifier.max}" value="0" inputmode="numeric">
            </label>
          </div>

          <div class="fos-dice__preview" aria-live="polite">
            <span>${localize("NextRoll")}</span>
            <strong data-part="preview">1d20</strong>
          </div>

          <fieldset class="fos-dice__fieldset">
            <legend>${localize("QuickDice")}</legend>
            <div class="fos-dice__grid">${diceButtons}</div>
          </fieldset>

          <label class="fos-dice__visibility">
            <span>${localize("Visibility")}</span>
            <select name="visibility">
              <option value="public">${localize("VisibilityPublic")}</option>
              <option value="gm">${localize("VisibilityGM")}</option>
              <option value="blind">${localize("VisibilityBlind")}</option>
              <option value="self">${localize("VisibilitySelf")}</option>
            </select>
          </label>

          <form class="fos-dice__custom" data-form="custom-roll">
            <label for="fos-dice-custom-formula">${localize("CustomFormula")}</label>
            <div class="fos-dice__formula-row">
              <input
                id="fos-dice-custom-formula"
                name="custom-formula"
                type="text"
                maxlength="${MAX_CUSTOM_FORMULA_LENGTH}"
                placeholder="${localize("FormulaPlaceholder")}" 
                autocomplete="off"
                spellcheck="false">
              <button type="submit">
                <i class="fa-solid fa-dice" aria-hidden="true"></i>
                <span>${localize("Roll")}</span>
              </button>
            </div>
            <p>${localize("FormulaHelp")}</p>
          </form>
        </div>
      </section>
    `;
  }

  bindEvents() {
    this.launcher.addEventListener("click", () => this.toggle());
    this.root.querySelector("[data-action='close']").addEventListener("click", () => this.close());
    this.countInput.addEventListener("input", () => this.updatePreview());
    this.modifierInput.addEventListener("input", () => this.updatePreview());

    for (const button of this.root.querySelectorAll("[data-action='quick-roll']")) {
      button.addEventListener("mouseenter", () => this.updatePreview(button.dataset.sides));
      button.addEventListener("focus", () => this.updatePreview(button.dataset.sides));
      button.addEventListener("mouseleave", () => this.updatePreview());
      button.addEventListener("blur", () => this.updatePreview());
      button.addEventListener("click", () => this.rollQuick(button.dataset.sides));
    }

    this.root.querySelector("[data-form='custom-roll']").addEventListener("submit", (event) => {
      event.preventDefault();
      this.rollCustom();
    });
  }

  handleKeydown(event) {
    if (event.key === "Escape" && !this.panel.hidden) {
      this.close();
    }
  }

  open() {
    this.panel.hidden = false;
    this.launcher.setAttribute("aria-expanded", "true");
    requestAnimationFrame(() => this.panel.classList.add("is-open"));
    this.countInput.focus({ preventScroll: true });
  }

  close() {
    this.panel.classList.remove("is-open");
    this.panel.hidden = true;
    this.launcher.setAttribute("aria-expanded", "false");
    this.launcher.focus({ preventScroll: true });
  }

  toggle() {
    this.panel.hidden ? this.open() : this.close();
  }

  updatePreview(sides = 20) {
    if (!this.preview) return;

    this.preview.textContent = buildDiceFormula({
      count: this.countInput.value,
      sides,
      modifier: this.modifierInput.value,
    });
  }

  async rollQuick(sides) {
    const formula = buildDiceFormula({
      count: this.countInput.value,
      sides,
      modifier: this.modifierInput.value,
    });

    await this.roll(formula);
  }

  async rollCustom() {
    const formula = this.customFormulaInput.value.trim();

    if (!formula) {
      ui.notifications.warn(localize("FormulaRequired"));
      this.customFormulaInput.focus();
      return;
    }

    await this.roll(formula);
  }

  async roll(formula) {
    if (this.isRolling) return;

    const normalizedFormula = String(formula).trim();

    if (!normalizedFormula || normalizedFormula.length > MAX_CUSTOM_FORMULA_LENGTH) {
      ui.notifications.error(localize("InvalidFormula"));
      return;
    }

    const RollClass = getRollClass();
    const ChatMessageClass = getChatMessageClass();

    if (!RollClass || !ChatMessageClass) {
      ui.notifications.error(localize("ApiUnavailable"));
      return;
    }

    try {
      if (typeof RollClass.validate === "function" && !RollClass.validate(normalizedFormula)) {
        throw new Error(localize("InvalidFormula"));
      }

      this.setRolling(true);

      const roll = typeof RollClass.create === "function"
        ? RollClass.create(normalizedFormula)
        : new RollClass(normalizedFormula);

      await roll.evaluate();

      const generation = getFoundryGeneration();
      const mode = getFoundryMessageMode(
        normalizeVisibilityMode(this.visibilitySelect.value),
        generation,
      );
      const messageOptions = generation >= 14
        ? { messageMode: mode }
        : { rollMode: mode };

      await roll.toMessage({
        flavor: localize("ChatFlavor"),
        speaker: ChatMessageClass.getSpeaker(),
      }, messageOptions);
    } catch (error) {
      console.error(`${MODULE_ID} | Dice roll failed`, error);
      ui.notifications.error(`${localize("RollFailed")} ${error.message ?? ""}`.trim());
    } finally {
      this.setRolling(false);
    }
  }

  setRolling(isRolling) {
    this.isRolling = isRolling;
    this.root.classList.toggle("is-rolling", isRolling);

    for (const button of this.root.querySelectorAll("[data-action='quick-roll'], [data-form='custom-roll'] button")) {
      button.disabled = isRolling;
    }
  }
}

Hooks.once("ready", () => {
  const tray = new FantasyOSDiceTray();
  tray.mount();

  const module = game.modules.get(MODULE_ID);
  if (module) {
    module.api = {
      open: () => tray.open(),
      close: () => tray.close(),
      roll: (formula, visibility = "public") => {
        tray.visibilitySelect.value = normalizeVisibilityMode(visibility);
        return tray.roll(String(formula));
      },
    };
  }

  console.info(`${MODULE_ID} | Ready`);
});
