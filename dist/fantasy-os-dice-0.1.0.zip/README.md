# Fantasy-OS Dice

Ein kleines, systemunabhängiges Würfelmodul für Foundry VTT. Es ergänzt einen kompakten Würfelbecher, dessen Ergebnisse über Foundrys eigene Würfel-API im Chat landen.

## Funktionen

- Schnellwürfel für W4, W6, W8, W10, W12, W20 und W100
- Frei wählbare Würfelanzahl und Modifikator
- Eigene Foundry-Formeln wie `2d20kh + 4`
- Öffentliche, private, verdeckte und nur selbst sichtbare Würfe
- Deutsche und englische Oberfläche
- Systemunabhängig und für Foundry VTT 13/14 ausgelegt

## Manuelle Installation

1. Lege im Foundry-Benutzerdatenverzeichnis unter `Data/modules/` einen Ordner namens `fantasy-os-dice` an.
2. Kopiere den gesamten Inhalt dieses Projekts in den neuen Ordner. `module.json` muss direkt in `Data/modules/fantasy-os-dice/` liegen.
3. Starte Foundry VTT neu.
4. Öffne deine Welt, wähle **Module verwalten**, aktiviere **Fantasy-OS Dice** und lade die Welt neu.

Danach erscheint unten rechts neben der Foundry-Seitenleiste die Schaltfläche **Würfeln**.

## API für spätere Fantasy-OS-Anbindung

Das Modul stellt nach dem Foundry-Hook `ready` eine kleine API bereit:

```js
const dice = game.modules.get("fantasy-os-dice").api;

dice.open();
await dice.roll("1d20 + 5", "public");
```

Erlaubte Sichtbarkeiten sind `public`, `gm`, `blind` und `self`. Damit kann eine spätere Charakterbogen- oder Portal-Integration Würfe auslösen, ohne die Oberfläche nachbauen zu müssen.

## Entwicklung

Die lokalen Prüfungen benötigen nur Node.js und keine zusätzlichen Pakete:

```sh
npm run check
```

Ein echter Integrationstest muss innerhalb einer Foundry-Welt erfolgen, weil Foundrys Browser-APIs außerhalb der Anwendung nicht verfügbar sind.
